<?php

/*
 * Creen una clase REAL de Autenticación.
 *
 * 1. Registrar Usuarios - username, password, email.
 * 2. Hash Password - Blowfish / Bcrypt (password_hash).
 * 3. Iniciar Sesion - email, password.
 */

