<?php

// Crear una clase de Autenticación

// Register y Login Retornan True o False

