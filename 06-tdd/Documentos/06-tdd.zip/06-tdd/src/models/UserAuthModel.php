<?php

// Conexion DB

// Crear una clase que internamente maneje los querys

class UserAuthModel
{
    // register(){} Correos Unicos
    // login(){}
}

